import React from 'react'
import { useSelector } from 'react-redux'

function HooksCakeContainer() {
    const numOfCakes = useSelector (state => state.numOfCakes)
    return (
        <div>
            <h1>React/Redux Hooks - Number of Cake: { numOfCakes } </h1>
            <button>React/Redux Hooks: Buy Cake</button>
        </div>
    )
}

export default HooksCakeContainer
