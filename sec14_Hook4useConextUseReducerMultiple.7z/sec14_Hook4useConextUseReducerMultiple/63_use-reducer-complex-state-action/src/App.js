import React from 'react';
import './App.css';
// import CounterOne from './components/CounterOne'
import CounterTwo from './components/CounterTwo'
function App() {
  return (
    <div className="App">
      <CounterTwo />
      {/* <CounterOne /> */}
    </div>
  );
}
export default App;
