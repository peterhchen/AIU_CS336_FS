import React from 'react';
import './App.css';
import CounterOne from './components/CounterOne'

function App() {
  return (
    <div className="App">
      <CounterOne />
    </div>
  );
}
export default App;
