import React, { Component } from 'react';
import './App.css';
import FocusInputClass  from './components/FocusInputClass'

class App extends Component {
  render () {
    return (
      <div className="App">
        <FocusInputClass />
      </div>
    );
  }
}

export default App;