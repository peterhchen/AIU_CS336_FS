import React, { Component } from 'react';
import './App.css';
import FRParentInput from './components/FRParentInput'

class App extends Component {
  render () {
    return (
      <div className="App">
        <FRParentInput />
      </div>
    );
  }
}

export default App;