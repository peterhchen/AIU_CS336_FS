import React from 'react';
import './App.css';
import DataFetching from './components/DataFetching'

function App() {
  return (
    <div className="App">
      <DataFetching  />
    </div>
  );
}

export default App;
