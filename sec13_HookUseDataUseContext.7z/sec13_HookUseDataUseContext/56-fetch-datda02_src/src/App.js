import React from 'react';
import './App.css';
import DataFetchingID from './components/DataFetchingID'

function App() {
  return (
    <div className="App">
      <DataFetchingID  />
    </div>
  );
}

export default App;
