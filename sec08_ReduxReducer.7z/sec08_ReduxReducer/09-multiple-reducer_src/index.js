// import redux from 'redux'
// Since we use simple node application, we have to use require syntax.
const redux = require ('redux')
const createStore = redux.createStore

console.log('From index.js')

const BUY_CAKE = 'BUY_CAKE'
const BUY_ICECREAM = 'BUY_ICECREAM'

function buyCake () {
    return {
        type: BUY_CAKE,
        info: 'Buy Cake'
    }
}

function buyIceCream () {
    return {
        type: BUY_ICECREAM,
        info: 'Buy Ice Cream'
    }
}

const initialState = {
    numOfCakes: 10,
    numOfIceCreams: 20
}

const reducer = (state = initialState, action) => {
    switch (action.type) {
        case BUY_CAKE:
            return {
                ...state,
                numOfCakes: state.numOfCakes -1
            }
            case BUY_ICECREAM:
                return {
                    ...state,
                    numOfIceCreams: state.numOfIceCreams -1
                }
        default: return state

    }
}

const store = createStore (reducer)
// get the initial state
console.log ('Initial State: ', store.getState())
// Note: unsubscribe is getting from the return of subscribe method.
const unsubscribe = store.subscribe (() => console.log ('Update state: ', store.getState()))
store.dispatch (buyCake())
store.dispatch (buyCake())
store.dispatch (buyCake())
store.dispatch (buyIceCream())
store.dispatch (buyIceCream())
// After everything is done, we need to unscribe the Redux store.
unsubscribe()
