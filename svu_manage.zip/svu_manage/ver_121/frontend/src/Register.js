import { useState } from 'react';

const cList = [
    { 
        "course_no_title": "CE450 Computer Architecture I",
        "trimester": "2015 Fall Trimester", "credit": 3, "id": 1
    },
    {
        "course_no_title": "CS440 Computer Networks I",
        "trimester": "2015 Fall Trimester",
        "credit": 3, "id": 2
    },
    {
        "course_no_title": "CS596-012 SP: XML and Application",
        "trimester": "2015 Fall Trimester",
        "credit": 3,
        "id": 3
    }];

const Register = () => {
    const [courseList, setCourseList] = useState (cList);
    const [courseNoTitle, setCourseNoTitle] = useState(cList[0].course_no_tile);
    const [studentId, setStudentId] = useState('');
    const [studentName, setStudentName] = useState('');
    const [textArea, setTextArea] = useState('');

    const handleSubmit = (e) => {
        e.preventDefault();  // Keep data/prevent page refreshing to default. 
        const course = { courseNoTitle, studentId, studentName };
        console.log ('course:', course);
        fetch('http://localhost:8000/transcripts/', {
            method: 'POST',
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(course)
        }).then(() => {
            console.log('new course added');
        })
    }

    return (  
        <div className="register">
            <h2>Create a New Registration</h2>
            <form onSubmit = { handleSubmit }>
                <div>
                    <label>Course No: </label>
                    <select
                        value = { courseList.course_no_title }
                        onChange = { (e) => setCourseNoTitle(e.target.value)}>
                    
                    {
                        courseList.map((item) => 
                        <option key = {item.id} value = { item.course_no_title } > { item.course_no_title }</option>)
                    }
                    
                    {/*
                        <option value = "EE450: Computer Architecture I">EE450: Computer Architecture I</option>
                        <option value = "CS440: Computer Network I">CS440: Computer Network I</option>
                    */}
                    </select>                      
                </div>
                {/* <p>EE450: Computer Architecture; Time, Date: 6-9pm, Mon; Trimester, Year: Spring, 2025; Credit: 3, Instrcutor: Peter</p> */}
                { courseNoTitle && <p>{courseNoTitle + ':'}</p> }
                <button>Delete Course</button>
                <br></br>
                <label>Student ID:</label>
                <input 
                    type ="text"
                    required
                    value = { studentId }
                    onChange = {(e) => setStudentId (e.target.value)}
                ></input>
                <br></br>
                <label>Student Name:</label>
                <input 
                    type ="text"
                    required
                    value = { studentName }
                    onChange = {(e) => setStudentName(e.target.value)} 
                ></input>
                <br></br>
                <label>Degree:</label>
                <input 
                    type ="text"
                    required 
                ></input>
                <br></br>
                <label>Major:</label>
                <input 
                    type ="text"
                    required 
                ></input>
                <br></br>
                <label>Birthday:</label>
                <input 
                    type ="text"
                    required 
                ></input>
                <br></br>
                <label>Date of Admission:</label>
                <input 
                    type ="text"
                    required 
                ></input>
                <br></br>
                <label>Comment:</label>
                <textarea
                    value = { textArea }
                    onChange = {(e) => setTextArea(e.target.value)} 
                ></textarea>
                <br></br>
                <button>Submit</button>
            </form>
            <p>{" Student ID: " + studentId } {'; Student Name: ' + studentName } {'; Text Area: ' + textArea } {'; Course No/Title: ' + courseNoTitle }</p>
        </div>
    );
}
 
export default Register;