import { useParams } from 'react-router-dom';
import useFetch from './useFetch';

const TranscriptDetails = () => {
    const { id } = useParams()
    const { data: course, isLoading, error } =  useFetch('http://localhost:8000/transcripts/' + id );
    return (  
        <div className="transcript-details">
            <h2>Transcript Details: { id }</h2>
            { isLoading && <div>Loading ...</div> }
            { error && <div> { error } </div> }
            { course && (
                <article>
                    <h2> { course.title } </h2>
                    {course.page} &emsp; {course.trimester} &emsp; {course.course_no} &emsp; {course.title} &emsp; 
                    { course.credit_attempted } &emsp; {course.credit_earned} &emsp; 
                    {course.grade } &emsp; {course.points }
                </article>
            )}
        </div>
    );
}
 
export default TranscriptDetails;