# https://www.youtube.com/watch?v=9N6a-VLBa2I
# json: JavaScript Object Notation
import json
transcript_string = '''
{
    "kw": "John Smith; DOB: 12-23-1995, 2023/01/2301020001",
    "DOB": "12-23-1995",
    "name": "John Smith",
    "STUDENT_ID": "2301020001",
    "course": [
        {
            "course_no": "CS599",
            "title": "Machine Learning",
            "grade": "A",
            "points": null,
            "credit": true
        },
        {
            "course_no": "CS650",
            "title": "Reinfocrment Learning",
            "grade": "A+",
            "points": 4.3,
            "credit": true
        }
    ]
}
'''
data = json.loads(transcript_string)

# json object to type of string:
# https://python.readthedocs.io/en/stable/library/json.html
# JSON          <=> Python
# object        <=> dict
# array         <=> list
# string        <=> str
# number (int)  <=> int
# number (real) <=> float
# true          <=> True
# false         <=> False
# null          <=> None 
print('type(data):', type(data))
print()
print('data:', data)
print()
# true => True
# null => None
# type(data): <class 'dict'>
# data: {'kw': 'John Smith; DOB: 12-23-1995, 2023/01/2301020001', 'DOB': '12-23-1995', 
# 'name': 'John Smith', 'STUDENT_ID': '2301020001', 
# 'course': 
# [{'course_no': 'CS599', 'title': 'Machine Learning', 'grade': 'A', 'points': None, 'credit': True}, 
# {'course_no': 'CS650', 'title': 'Reinfocrment Learning', 'grade': 'A+', 'points': 4.3, 'credit': True}]}
# 
# The orgianl string comtains an object and array. Now, convert into Python is a dictionary amd list. 
print('data["course"]:', data["course"])
print()
# data["course"]: [{'course_no': 'CS599', 'title': 'Machine Learning', 'grade': 'A', 'points': None, 'credit': True}, 
# {'course_no': 'CS650', 'title': 'Reinfocrment Learning', 'grade': 'A+', 'points': 4.3, 'credit': True}]

# Now, we have convert the json string into python object.
# It is a lot easier to work with.
# We can loop through all the course.
print('loop trhough course list:')
for course in data['course']:
    print('course: ', course)
# course:  {'course_no': 'CS599', 'title': 'Machine Learning', 'grade': 'A', 'points': None, 'credit': True}
# course:  {'course_no': 'CS650', 'title': 'Reinfocrment Learning', 'grade': 'A+', 'points': 4.3, 'credit': True}

for course in data['course']:
    print('course["course_no"]: ', course["course_no"])
print()
# course["course_no"]:  CS599
# course["course_no"]:  CS650

# Then, we can reverse the python object and write into the json format for database.
# We dump the data dictionary into json string.
new_string = json.dumps (data)

print('new_string: ', new_string)
print()

# We can put the nicer indent string.
new_indent_string = json.dumps (data, indent= 4)

print('new_indent_string: ', new_indent_string)
