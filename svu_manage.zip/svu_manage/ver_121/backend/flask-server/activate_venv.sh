#!/bin/bash
# usage: source activate_venv.sh
#source "/home/peter/work/svu_manage/backend/flask-server/venv/bin/activate"
source "./venv/bin/activate"
# type "deactivate" to exit venv
