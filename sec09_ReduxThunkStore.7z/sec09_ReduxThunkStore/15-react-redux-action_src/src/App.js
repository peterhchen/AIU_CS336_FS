import React from 'react'
import './App.css'
import CakeContainer from './components/CakeContainer'

function App() {
  return (
    <div className="App">
      <CakeContainer />
    </div>
  );
}

export default App;
