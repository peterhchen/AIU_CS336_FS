import React from 'react'
import ComponentD from './ComponentD'
function ComponentB() {
    return (
        <div>
            <ComponentD />
        </div>
    )
}

export default ComponentB
