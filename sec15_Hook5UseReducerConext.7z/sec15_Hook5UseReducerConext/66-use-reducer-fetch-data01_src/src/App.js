import React from 'react';
import './App.css';
import DataFetchingOne from './components/DataFetchingOne'

function App() {
  return (
    <div className="App">
      <DataFetchingOne />
    </div>
  );
}
export default App;
