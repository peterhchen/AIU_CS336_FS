import React from 'react';
import './App.css';
// import DataFetching from './components/DataFetching'
import DataFetchingTwo from './components/DataFetchingTwo'

function App() {
  return (
    <div className="App">
      {/* <DataFetching  /> */}
      <DataFetchingTwo />
    </div>
  );
}

export default App;
